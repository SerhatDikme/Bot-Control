<?php 

$ch=curl_init();

curl_setopt_array($ch, 
	[
	CURLOPT_URL => 'http://localhost/curl/08-agent.php',
	CURLOPT_SSL_VERIFYPEER => 'false',
	CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'
	]);

curl_exec($ch);
curl_close($ch);

 ?>

