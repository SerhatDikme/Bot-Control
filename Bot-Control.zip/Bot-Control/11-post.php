<?php 
echo "This is the posted file";
echo "<pre>";
print_r($_POST);

 ?>