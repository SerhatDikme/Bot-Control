<?php 

$file=fopen("source.txt","w");

$ch=curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://codeepicenter.com');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_FILE, $file);

if (curl_exec($ch)) {
	echo "Successfully written source code to file";
}

curl_close($ch);

 ?>