<?php 


$ch=curl_init('http://www.php.net');

curl_exec($ch);
curl_close($ch);

 ?>

