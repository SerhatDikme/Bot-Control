<?php 
//GET İşlemi

$get="http://localhost/curl/12-get.php?ara=emrah";
$ch=curl_init($get);

curl_exec($ch);
curl_close($ch);

?>

