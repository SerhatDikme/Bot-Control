<?php 
/*
cURL Process
*/

//cURL Started
$ch=curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://codeepicenter.com');
//SSL Connected
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

//Curl Start
$source=curl_exec($ch);

//Curl end
curl_close($ch);

 ?>