<?php 

$ch=curl_init();

curl_setopt_array($ch, 
	[
		CURLOPT_URL => 'https://www.codeepicenter.com',
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_RETURNTRANSFER => 1
	]);

$veri=curl_exec($ch);
curl_close($ch);

preg_match('@<title>(.*?)</title>@', $data, $result);
echo "<pre>";
print_r($result);
echo $result[1];
echo "<hr>";
preg_match_all('@<h5 class="mt-5 mb-5">(.*?)</h5>@si', $data, $result);
echo "<pre>";
foreach ($result[1] as $key) {
	echo $key."<br/>";
}
?>

