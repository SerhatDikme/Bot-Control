<?php 


$ch=curl_init('http://localhost/curl/11-post.php');

curl_setopt_array($ch, 
	[
		CURLOPT_POST => "true",
		CURLOPT_POSTFIELDS => [
			"name" => ".....",
			"pass" => "....",
			"submit" => 1
		]
	]);

curl_exec($ch);
curl_close($ch);

?>
