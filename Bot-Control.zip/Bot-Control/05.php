<?php 
/*

curl_setopt function

*/

$ch=curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://codeepicenter.com');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//Transfer source code
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$source=curl_exec($ch);

echo $source;
curl_close($ch);

 ?>