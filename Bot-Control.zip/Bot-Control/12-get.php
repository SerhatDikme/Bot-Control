<?php 
echo "This is the get sent file";
echo "<pre>";
print_r($_GET);


if ($_GET['search']=="(name)") {
	echo "Show Records";
}
 ?>