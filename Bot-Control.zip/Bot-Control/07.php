<?php 
//REFERER

$ch=curl_init();

curl_setopt($ch, CURLOPT_URL, 'http://localhost/curl/07-referer.php');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_REFERER, 'http://www.codeepicenter.com');
curl_exec($ch);
curl_close($ch);

 ?>

