<?php


if (!isset($_SERVER['HTTP_REFERER'])) {
	echo "Sorry, I didn't recognize";
} else {
	echo "You Came From Here...: ".$_SERVER['HTTP_REFERER'];
}
?>
