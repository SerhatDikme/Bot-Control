<?php 
session_start();

if (isset($_POST['login'])) {
	
	if ($_POST['name']=="codeepicenter" && $_POST['pass']="1234") {
		
		$_SESSION['name']=$_POST['name'];

		Header("Location:index.php");
	} else {

 	echo "check your informations...";
 	echo "<a href='index.php'>Back</a>";
}


} 




 ?>