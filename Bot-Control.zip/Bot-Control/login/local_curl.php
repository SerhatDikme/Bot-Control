<?php 

$ch=curl_init();

curl_setopt_array($ch, 
	[

			// Your process.php in online website
		// CURLOPT_URL => '',
		CURLOPT_SSL_VERIFYPEER => false,
		CURLOPT_POST => TRUE,
		CURLOPT_POSTFIELDS => 
		[
			"name" => "codeepicenter",
			"pass" => "1234",
			"login" => 1
		],
		CURLOPT_FOLLOWLOCATION => 1,
		CURLOPT_COOKIEJAR => "cookies.txt"
	]);

curl_exec($ch);
curl_close($ch);


?>