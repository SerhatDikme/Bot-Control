<?php 

$ch=curl_init();

curl_setopt_array($ch, 
	[
		CURLOPT_URL => 'http://localhost/curl/login/islem.php',
		CURLOPT_POST => TRUE,
		CURLOPT_POSTFIELDS => 
		[
			"kadi" => "codeepicenter",
			"pass" => "1234",
			"login" => 1
		],
		CURLOPT_FOLLOWLOCATION => 1,
		CURLOPT_COOKIEJAR => "cookies.txt"
	]);

curl_exec($ch);
curl_close($ch);


	?>