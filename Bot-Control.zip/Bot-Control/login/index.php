<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>

	<?php if (isset($_SESSION['name'])) {?>

		<h2>My Account</h2><br>
		Welcome <?php echo $_SESSION['name'] ?>

		<p><a href="out.php">Out</a></p>

	<?php } else {?>
		<form action="process.php" method="POST">
			K.Adı <input type="text" name="name">
			Şifre <input type="text" name="pass">
			<input type="submit" name="login">
		</form>
		<br>
		<a href="curl.php">Bot Login</a>

	<?php }?>



</body>
</html>